GitHub Pages용 로고 수정 버전입니다.
index.html 하나만 업로드해도 로고가 보이도록 data URI로 직접 포함했습니다.
